
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  base: './', 
  server: {
    port: 3000,
    host: '0.0.0.0',
  },
  define: {
    // API KEY GEMINI
    'process.env.API_KEY': JSON.stringify('AIzaSyA_ISI_API_KEY_GEMINI_BAPAK'),
    
    // CONFIG SUPABASE (Database Utama)
    'process.env.SUPABASE_URL': JSON.stringify('https://rycuxmxyosqerqgcllvu.supabase.co'),
    'process.env.SUPABASE_KEY': JSON.stringify('eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJ5Y3V4mxyosqerqgcllvuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDEzMTgxMTksImV4cCI6MjA1NjI5NDExOX0.E076I0_78V5TfBf8I0_78V5TfBf8I0_78V5TfBf8'),
    
    // CONFIG GOOGLE DRIVE BRIDGE (3 Slot Wajib)
    // Mirror 1: Untuk pecah data ke Tab-Tab Google Sheets
    'process.env.GDRIVE_SHEET_URL': JSON.stringify('PASTE_URL_WEB_APP_1_SHEETS_BAPAK'),
    
    // Mirror 2 & Photo Vault: Untuk Backup JSON & Simpan Foto Resep
    'process.env.GDRIVE_JSON_URL': JSON.stringify('PASTE_URL_WEB_APP_2_JSON_BAPAK'),
    
    // Auto-Reporting: Untuk ekspor file Excel otomatis
    'process.env.GDRIVE_EXCEL_URL': JSON.stringify('PASTE_URL_WEB_APP_3_EXCEL_BAPAK'),
    
    // CONFIG FIREBASE (Mirror 4)
    'process.env.FIREBASE_URL': JSON.stringify('https://ISI_URL_FIREBASE_BAPAK_DISINI'),

    // CONFIG MYSQL (Mirror 3)
    'process.env.MYSQL_API_URL': JSON.stringify('https://domainanda.com/api_lembah.php')
  },
  build: {
    outDir: 'dist',
    assetsDir: 'assets',
    sourcemap: false
  }
});
